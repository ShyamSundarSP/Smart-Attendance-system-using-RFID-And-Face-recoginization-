<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="dash.css" type="text/css" />
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
</head>
<body>
    <section>
        <div class="icons">
            <div class="home">
                <img src="images\home.jpg">
                <h2><a href="https://login.changers.website/page1.php"><button class="button-base ripple">HOME</a></h2>
            </div>

            <div class="dashboard">
                <img src="images\dashboard.jpg">
                <h2><a href="#"><button class="button-base ripple">DASHBOARD</a></h2>
            </div>
            <div class="ranking">
                <img src="images\grade.jpg">
                <h2><a href="https://trial4.changers.website/class.php"><button class="button-base ripple">RECORD</a></h2>
            </div>

            <div class="log out">
                <a href="https://changers.website/"><button class="button-base ripple">LOG OUT</buttonclass=""></a>
            </div>
        </div>
        <div class="shyam">
            <br>
            <br>
            <br>
            <h2><bold>DASHBOARD</bold></h2>
        </div>
    </section>
    <br>
    <br>
    <br>
    <br>
    <section>
            <style type="text/css">
        table{
            border-collapse: collapse;
            width: 100%;
            color: #000;
            font-family: monoscape;
            font-size: 25px;
            text-align: left;
            padding: 100px;
        }
        th {
            background-color:  #eb4034;
            color: white;
        }
        tr:nth-child(even) {background-color: #ededed}
    </style
    </section>
    <section class="clatson">
        <table>
        <tr>
            <th>Name</th>
            <th>Total No of Working Days</th>
            <th>No of Days Present</th>
            <th>No of Days Absent</th>
            <th>Attendance Percentage</th>
        </tr>
        <?php

            $servername = "localhost";
            $database = "u394450735_Student_data";
            $username = "u394450735_SIH";
            $password = "Game@123456789";
            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $database);
            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            
            $query = "SELECT * FROM data;";
            $result = $conn -> query($query);
            $resultcheck = mysqli_num_rows($result);
            if($resultcheck > 0){
                while ($row = mysqli_fetch_assoc($result)){
                   echo "<tr><td>".$row["name"] ."</td><td>".$row["working"] ."</td><td>".$row["present"] ."</td><td>".$row["absent"]. "</td><td>".$row["percentage"] ."</td><tr>";
                }
            }
                
            
        ?>
    </table>
    </section>

</body>
</html>
