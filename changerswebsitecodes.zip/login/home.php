<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Login Page</title>
    <link rel="icon" href="icon1.png" type="image/x-icon" />
    <link rel="stylesheet" href="loginstyle.css" type="text/css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&display=swap" rel="stylesheet">
</head>
<body>
    <div class="login-div">
        <div class="logo"><img src="images\cartoon.jpg" height="150" width="150" alt="" /></div>
        <div class="title"><strong>Login</strong></div>
        <div class="sub-title"></div>

        <div class="form">
            <form method="post">
                <div class="username">
                    <input type="text" name="mail" placeholder="Email ID" />
                </div>
                <div class="password">
                    <input type="password" name="password" placeholder="Password" />
                </div>
                </div>
                    <input type="submit" />
                <div class="option">
            </form>
        
                
                <div class="forget-password">
                    <a href="#">Forget Password?</a>
                </div>

        </div>
    </div>
    <?php
    $m = $_POST['mail'];
    $p = $_POST['password'];
    
    $servername = "localhost";
        $database = "u394450735_Student_data";
        $username = "u394450735_SIH";
        $password = "Game@123456789";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $database);
        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
       
        $query = "SELECT * FROM webpage WHERE mail='$m' and password='$p';";
        $result = $conn -> query($query);
        $resultcheck = mysqli_num_rows($result);
        if($resultcheck > 0){
            while ($row = mysqli_fetch_assoc($result)){
                session_start();

	//session_destroy();
	//unset($_SESSION['username']);

	            if (isset($_SESSION['username'])) {
	                $url = "https://trial4.changers.website/page1.php";
	                header('Location: ' . $url);
	                exit();
		             
		          
		    
	            } else if (isset($_POST['mail'])) {
		            $email = $_POST['mail'];
		            $_SESSION['mail'] = $email;
		            $url = "page1.php";
		            header('Location: ' . $url);
		            exit();
	            } 
            }
        }
        
        

         $connection->close();

    
    
    ?>


   <?php
	
	?>
