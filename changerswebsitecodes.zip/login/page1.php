<?php
    session_start();

	if (!isset($_SESSION['mail'])) {
		header("Location: home.php");
		exit();
	}

	$mail = $_SESSION['mail'];
?>
<style>
        * {
    text-decoration: none;
    align-items: center;
    text-align: center;
    background-color: ;
}

body {
    background-color: white;
}


.home {
    display: flex;
    text-decoration: none;
}

.dashboard {
    display: flex;
    text-decoration: none;
}

.ranking {
    display: flex;
    text-decoration: none;
}

.home img {
    height: 30px;
    width: 30px;
    border-radius: 50%;
}
.button-base {
    font-family: 'Roboto', sans-serif;
    -webkit-appearance: none;
    border: none;
    text-transform: none;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    background: #59c9fc;
    color: #b6ff00;
    vertical-align: middle;
    border-radius: 50px;
    line-height: 36px;
    min-height: 36px;
    font-size: 14px;
    text-align: center;
    text-decoration: none;
    text-transform: uppercase;
    min-width: 5.14em;
    padding: 0 1em;
    margin: 0 0.25em;
    box-shadow: 0 1px 4px 0 rgba(0,0,0,0.37);
}

.button-base:focus {
    outline: 0;
}

.button-base:hover {
    box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2), 0 6px 10px 0 rgba(0, 0, 0, 0.3);
}

.ripple {
    position: relative;
    overflow: hidden;
}

.ripple:before {
    border-radius: 50%;
    background-color: rgba(255,255,255,0.6);
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
}

.ripple:focus:before {
    transition: all 0.5s ease-out;
    opacity: 0;
    width: 160px;
    height: 160px;
    margin-top: -80px;
    margin-left: -80px;
}

.ranking img {
    height: 30px;
    width: 30px;
    border-radius: 150%;    
}

.dashboard img {
    height: 30px;
    width: 30px;
    border-radius: 150%;
}

.table-bordered {
    align-items: center;
    margin-top: 30px;
}

.abc {
    align-content: center;
}

.icons {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    padding: 5px 0px;
    margin-top: 10px;
}

.box1 {
    left: 30px;
}

.a2d {
    text-align: center;
    margin
}

.table-bordered {
    margin-left: 33%;
    font-size: 18px;
    padding: 10px 20px 10px 5px;
    border: solid;
    outline:0;
    background-color: white;
}

.box-11 img {
    border-radius: 50%;
    border: 6px white solid;
}

    </style>

<body>
    <?php

        $servername = "localhost";
        $database = "u394450735_Student_data";
        $username = "u394450735_SIH";
        $password = "Game@123456789";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $database);
        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        
        $query = "SELECT * FROM webpage WHERE mail='$mail';";
        $result = $conn -> query($query);
        $resultcheck = mysqli_num_rows($result);
        if($resultcheck > 0){
            while ($row = mysqli_fetch_assoc($result)){
                $mail = $row['mail'];
                $year = $row['year'];
                $id = $row['id'];
                $class=$row['class'];
                $name=$row['name'];
                $gender=$row['gender'];
                $roll=$row['roll'];
            }
        }
    

    ?>
    <section>
        <div class="icons">
            <div class="home">
                <img src="images\home.jpg">
                <h2><a href="#"><button class="button-base ripple">HOME</a></h2>
            </div>

            <div class="dashboard">
                <img src="images\dashboard.jpg">
                <h2><a href="https://trial4.changers.website/dash1.php"><button class="button-base ripple">DASHBOARD</a></h2>
            </div>
            <div class="ranking">
                <img src="images\grade.jpg">
                <h2><a href="https://trial4.changers.website/class.php"><button class="button-base ripple">RECORD</a></h2>
            </div>

            <div class="log out">
                <a href="https://changers.website/"><button class="button-base ripple">LOG OUT</buttonclass=""></a>
            </div>
        </div>
    </section>
    <section class="a2d">
        <div class="student">
            <div class="box1">
                <div class="box-11">

                    <img src="images\bevan.jpg" width="10%"height="25%" alt="student dp">
                </div>
                <div class="box-12">
                    <h3><?php
                        echo $name
                        ?></h3>
                </div>
            </div>

            <div class="box2">
                <div class="box22">
                    <h3 class="mb-0"><i class="far fa-clone pr-1"></i>General Information</h3>
                </div>
                <div class="box2-body pt-0">
                    <table class="table-bordered">
                        <tr class="abc">
                            <th width="30%">Name</th>
                            <td width="2%">:</td>
                            <td>
                                <?php
                                    echo $name;
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th width="30%">Student ID </th>
                            <td width="2%">:</td>
                            <td>
                                <?php
                                    echo $id;
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th width="30%">Class</th>
                            <td width="2%">:</td>
                            <td>
                                <?php
                                    echo $class;
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th width="30%">Roll</th>
                            <td width="2%">:</td>
                            <td>
                                <?php
                                    echo $roll;
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th width="30%">Academic Year </th>
                            <td width="2%">:</td>
                            <td>
                                <?php
                                    echo $year;
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th width="30%">Gender</th>
                            <td width="2%">:</td>
                            <td>
                                <?php
                                    echo $gender;
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
    </section>


</body>