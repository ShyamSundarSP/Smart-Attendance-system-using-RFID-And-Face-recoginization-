<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Default page</title>
        
        <meta charset="utf-8">
        <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
        <meta content="Default page" name="description">
        
    </head>
    <body>
        <h1>hello</h1>
        <a href="home.php">Click here</a>
    </body>
</html>