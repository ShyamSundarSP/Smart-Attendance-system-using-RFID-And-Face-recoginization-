<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Login Page</title>
    <link rel="icon" href="icon1.png" type="image/x-icon" />
    <link rel="stylesheet" href="loginstyle.css" type="text/css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&display=swap" rel="stylesheet">
</head>
<body>
    <div class="login-div">
        <div class="logo"><img src="images\cartoon.jpg" height="150" width="150" alt="" /></div>
        <div class="title"><strong>Login</strong></div>
        <div class="sub-title"></div>

        <div class="form">
            <form method="post">
                <div class="username">
                    <input type="text" name="mail" placeholder="Email ID" />
                </div>
                <div class="password">
                    <input type="password" name="password" placeholder="Password" />
                </div>
                </div>
                    <input type="submit" />
                <div class="option">
            </form>
        
                
                <div class="forget-password">
                    <a href="https://wa.me/+917540011837?text=I request you to please accept my request and change my password">Forget Password?</a>
                </div>

        </div>
    </div>
    <?php
    $m = $_POST['mail'];
    $p = $_POST['password'];
    
    $servername = "localhost";
        $database = "u394450735_Student_data";
        $username = "u394450735_SIH";
        $password = "Game@123456789";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $database);
        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
       
        $query = "SELECT * FROM webpage WHERE mail='$m' and password='$p';";
        $result = $conn -> query($query);
        $resultcheck = mysqli_num_rows($result);
        if($resultcheck > 0){
            while ($row = mysqli_fetch_assoc($result)){
                echo "f";
            }
        }
        
        

         $connection->close();

    
    
    ?>


   <?php
	
	?>
</body>
</html>

