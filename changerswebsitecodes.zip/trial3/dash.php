<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="dash.css" type="text/css" />
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
</head>
<body>
    <section>
        <div class="icons">
            <div class="home">
                <img src="images\home.jpg">
                <h2><a href="sh1.php"><button class="button-base ripple">HOME</a></h2>
            </div>

            <div class="dashboard">
                <img src="images\dashboard.jpg">
                <h2><a href="dash.php"><button class="button-base ripple">DASHBOARD</a></h2>
            </div>
            <div class="ranking">
                <img src="images\grade.jpg">
                <h2><a href="class.php"><button class="button-base ripple">CLASS</a></h2>
            </div>

            <div class="log out">
                <a href=""><button class="button-base ripple">LOG OUT</buttonclass=""></a>
            </div>
        </div>
        <div class="shyam">
            <br>
            <br>
            <br>
            <h2><bold>DASHBOARD</bold></h2>
        </div>
    </section>
    <br>
    <br>
    <br>
    <br>
    <section class="clatson">
        <table class="table-bordered">
            <tr class="abc">
                <th width="30%">TOTAL WORKING DAYS</th>
                <td width="2%">:</td>
                <td>210</td>
            </tr>
            <tr>
                <th width="30%">NO OF DAYS PRESENT </th>
                <td width="2%">:</td>
                <td>209</td>
            </tr>
            <tr>
                <th width="30%">NO OF DAYS ABSENT</th> </th>
                <td width="2%">:</td>
                <td>1</td>
            </tr>
            <tr>
                <th width="30%">ATTENDANCE PERCENTAGE</th> </th>
                <td width="2%">:</td>
                <td>99%</td>
            </tr>
        </table>
    </section>

</body>
</html>
