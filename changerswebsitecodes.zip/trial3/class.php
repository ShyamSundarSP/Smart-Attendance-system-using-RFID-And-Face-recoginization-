<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="dash.css" type="text/css" />
     <link rel="stylesheet" href="class.css" type="text/css" />
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
</head>
<body>
    <section>
        <div class="icons">
            <div class="home">
                <img src="images\home.jpg">
                <h2><a href="https://changers.website/"><button class="button-base ripple">HOME</a></h2>
            </div>

            <div class="dashboard">
                <img src="images\dashboard.jpg">
                <h2><a href="dash.php"><button class="button-base ripple">DASHBOARD</a></h2>
            </div>
            <div class="ranking">
                <img src="images\grade.jpg">
                <h2><a href="class.php"><button class="button-base ripple">CLASS</a></h2>
            </div>

            <div class="log out">
                <a href="https://changers.website/"><button class="button-base ripple">LOG OUT</buttonclass=""></a>
            </div>
            </div>
        </div>
        <div class="shyam">
            <br>
            <br>
            <br>
            <h2><bold>CLASS</bold></h2>
        </div>
        <section>    
    </style>

    <title>Attendance System</title>
    <style type="text/css">
        table{
            border-collapse: collapse;
            width: 100%;
            color: #000;
            font-family: monoscape;
            font-size: 25px;
            text-align: left;
            padding: 100px;
        }
        th {
            background-color:  #eb4034;
            color: white;
        }
        tr:nth-child(even) {background-color: #ededed}
    </style>
    <br>
    <br>
    <br>
    <br>
    <table>
        <tr>
            <th>Name</th>
            <th>ID</th>
            <th>Aug 29 2022</th>
            <th>Aug 30 2022</th>
            <th>Present</th>
            <th>No of working days</th>
            <th>Absent</th>
            <th>Percentage</th>
        </tr>
        <?php

            $servername = "localhost";
            $database = "u394450735_Student_data";
            $username = "u394450735_SIH";
            $password = "Game@123456789";
            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $database);
            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            
            $query = "SELECT * FROM data;";
            $result = $conn -> query($query);
            $resultcheck = mysqli_num_rows($result);
            if($resultcheck > 0){
                while ($row = mysqli_fetch_assoc($result)){
                   echo "<tr><td>".$row["name"] ."</td><td>".$row["id"] ."</td><td>".$row["aug29"] ."</td><td>".$row["aug30"] ."</td><td>".$row["present"] ."</td><td>".$row["absent"] ."</td><td>".$row["working"] ."</td><td>".$row["percentage"] ."</td><tr>";
                }
            }
                
            
        ?>
    </table>
    </section>
    </section>
    <br>
    <br>
    <div class="edit">
                <a href="https://auth-db844.hstgr.io/index.php?route=/sql&server=1&db=u394450735_Student_data&table=data&pos=0"
                    <br>
                    <br>
                    <button class="button-base ripple">edit</button></a>
    </div>                
<ul class="sel">
  Anto
  <div><button><a href="https://wa.me/+919791073543?text=This message is from gamechangers school.we inform you that your child is absent for todays session"><img src="images\R.png"></a></div>
  Bevan
  <button><a href="https://wa.me/+919791073543?text=This message is from gamechangers school.we inform you that your child is absent for todays session"><img src="images\R.png"></a></button></div>
  Clatson
  <button><a href="https://wa.me/+917540011837?text=This message is from gamechangers school.we inform you that your child is absent for todays session"><img src="images\R.png"></a></button></div>
  Sangamithra
  <button><a href="https://wa.me/+91733903882?text=This message is from gamechangers school.we inform you that your child is absent for todays session"><img src="images\R.png"></a></button>
  selva
  <button><a href="https://wa.me/+919659397009?text=This message is from gamechangers school.we inform you that your child is absent for todays session"><img src="images\R.png"></a></button>
  shyam
  <button><a href="https://wa.me/+919345453808?text=This message is from gamechangers school.we inform you that your child is absent for todays session"><img src="images\R.png"></a></button>
</ul>
<style>
    li {
  background: url("arrow.png") 0 50% no-repeat;
  list-style-type: none;
  padding-left: 12px;
  }
  .sel{
      margin-right:100%;
      border-radius: 10px;
  }
  }
</style>

</body>
</html>
