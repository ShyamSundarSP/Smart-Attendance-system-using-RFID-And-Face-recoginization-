 <!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="page1.css" />
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>
    <style>
        * {
    text-decoration: none;
    align-items: center;
    text-align: center;
    background-color: ;
}

body {
    background-color: white;
}


.home {
    display: flex;
    text-decoration: none;
}

.dashboard {
    display: flex;
    text-decoration: none;
}

.ranking {
    display: flex;
    text-decoration: none;
}

.home img {
    height: 30px;
    width: 30px;
    border-radius: 50%;
}
.button-base {
    font-family: 'Roboto', sans-serif;
    -webkit-appearance: none;
    border: none;
    text-transform: none;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    background: #59c9fc;
    color: #b6ff00;
    vertical-align: middle;
    border-radius: 50px;
    line-height: 36px;
    min-height: 36px;
    font-size: 14px;
    text-align: center;
    text-decoration: none;
    text-transform: uppercase;
    min-width: 5.14em;
    padding: 0 1em;
    margin: 0 0.25em;
    box-shadow: 0 1px 4px 0 rgba(0,0,0,0.37);
}

.button-base:focus {
    outline: 0;
}

.button-base:hover {
    box-shadow: 0 2px 2px 0 rgba(0, 0, 0, 0.2), 0 6px 10px 0 rgba(0, 0, 0, 0.3);
}

.ripple {
    position: relative;
    overflow: hidden;
}

.ripple:before {
    border-radius: 50%;
    background-color: rgba(255,255,255,0.6);
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
}

.ripple:focus:before {
    transition: all 0.5s ease-out;
    opacity: 0;
    width: 160px;
    height: 160px;
    margin-top: -80px;
    margin-left: -80px;
}

.ranking img {
    height: 30px;
    width: 30px;
    border-radius: 150%;    
}

.dashboard img {
    height: 30px;
    width: 30px;
    border-radius: 150%;
}

.table-bordered {
    align-items: center;
    margin-top: 30px;
}

.abc {
    align-content: center;
}

.icons {
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    padding: 5px 0px;
    margin-top: 10px;
}

.box1 {
    left: 30px;
}

.a2d {
    text-align: center;
    margin
}

.table-bordered {
    margin-left: 33%;
    font-size: 18px;
    padding: 10px 20px 10px 5px;
    border: solid;
    outline:0;
    background-color: white;
}

.box-11 img {
    border-radius: 50%;
    border: 6px white solid;
}

    </style>

    <title>Attendance System</title>
    <style type="text/css">
        table{
            border-collapse: collapse;
            width: 100%;
            color: #000;
            font-family: monoscape;
            font-size: 25px;
            text-align: left;
            padding: 100px;
        }
        th {
            background-color:  #eb4034;
            color: white;
        }
        tr:nth-child(even) {background-color: #ededed}
    </style>
</head>
<body>
       <div class="icons">
            <div class="home">
                <img src="images\home.jpg">
                <h2><a href="page1.php"><button class="button-base ripple">HOME</a></h2>
            </div>

            <div class="dashboard">
                <img src="images\dashboard.jpg">
                <h2><a href="dash1.php"><button class="button-base ripple">DASHBOARD</a></h2>
            </div>
            <div class="ranking">
                <img src="images\grade.jpg">
                <h2><a href="class.php"><button class="button-base ripple">RANKING</a></h2>
            </div>

            <div class="log out">
                <a href="https://changers.website/"><button class="button-base ripple">LOG OUT</buttonclass=""></a>
            </div>
        </div>
    </section>
    <section>    
    <h2>RANKING</h2>
    <br>
    <br>
    <br>
    <br>
    <table>
        <tr>
            <th>Name</th>
            <th>ID</th>
            <th>aug23</th>
            <th>aug24</th>
            <th>Present</th>
            <th>No of working days</th>
            <th>Absent</th>
            <th>Percentage</th>
        </tr>
        <?php

            $servername = "localhost";
            $database = "u394450735_Student_data";
            $username = "u394450735_SIH";
            $password = "Game@123456789";
            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $database);
            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            
            $query = "SELECT * FROM data;";
            $result = $conn -> query($query);
            $resultcheck = mysqli_num_rows($result);
            if($resultcheck > 0){
                while ($row = mysqli_fetch_assoc($result)){
                   echo "<tr><td>".$row["name"] ."</td><td>".$row["id"] ."</td><td>".$row["aug23"] ."</td><td>".$row["aug24"] ."</td><td>".$row["present"] ."</td><td>".$row["absent"] ."</td><td>".$row["working"] ."</td><td>".$row["percentage"] ."</td><tr>";
                }
            }
                
            
        ?>
    </table>
    </section>
    <section>
</body>    
</html>