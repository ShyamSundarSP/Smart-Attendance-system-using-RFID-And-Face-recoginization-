<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Login Page</title>
    <link rel="icon" href="icon1.png" type="image/x-icon" />
    <link rel="stylesheet" href="loginstyle.css" type="text/css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&display=swap" rel="stylesheet" />
 
</head>
<body>
   
    <h1>
        <a href = "student home.php">Click Here</a>
    </h1>
</html>
 

