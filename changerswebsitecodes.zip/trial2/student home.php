<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title>Login Page</title>
    <link rel="icon" href="icon1.png" type="image/x-icon" />
    <link rel="stylesheet" href="StyleSheet3.css" type="text/css" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
 
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400&display=swap" rel="stylesheet" />

</head>
<body>
    <section>
        <div class="icons">
            <div class="home">
                <img src="images\home.jpg">
                <h2><a href=""><button class="button-base ripple">HOME</a></h2>
            </div>

            <div class="dashboard">
                <img src="images\dashboard.jpg">
                <h2><a href="nothingstudent1.html"><button class="button-base ripple">DASHBOARD</a></h2>
            </div>
            <div class="ranking">
                <img src="images\grade.jpg">
                <h2><a href="sample1.html"><button class="button-base ripple">RANKING</a></h2>
            </div>

            <div class="log out">
                <a href=""><button class="button-base ripple">LOG OUT</buttonclass=""></a>
            </div>
        </div>
    </section>
    <?php

        $servername = "localhost";
        $database = "u394450735_Student_data";
        $username = "u394450735_SIH";
        $password = "Game@123456789";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $database);
        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        $s = 123456789;
        $query = "SELECT * FROM webpage WHERE id='$s';";
        $result = $conn -> query($query);
        $resultcheck = mysqli_num_rows($result);
        if($resultcheck > 0){
            while ($row = mysqli_fetch_assoc($result)){
                $mail = $row['mail'];
                $year = $row['year'];
                $id = $row['id'];
                $class=$row['class'];
                $name=$row['name'];
                $gender=$row['gender'];
            }
        }
    

    ?>
    
        
    <section>
       
    <section class="a2d">
        <div class="student">
            <div class="box1">
                <div class="box-11">

                    <img src="images/abc.jfif" width="25%" height="25%" alt="student dp">
                </div>
                <div class="box-12">
                    <h3>
                        
                    </h3>
                </div>
            </div>

            <div class="box2">
                <div class="box22">
                    <h3 class="mb-0"><i class="far fa-clone pr-1"></i>General Information</h3>
                </div>
                <div class="box2-body pt-0">
                    <table class="table-bordered">
                        <tr class="abc">
                            <th width="30%">Name</th>
                            <td width="2%">:</td>
                            <td>
                                <?php
                                    echo $name;
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th width="30%">Student ID </th>
                            <td width="2%">:</td>
                            <td>
                                <?php
                                    echo $id;
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th width="30%">Class</th>
                            <td width="2%">:</td>
                            <td>
                                  <?php
                                    echo $class;
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th width="30%">Roll</th>
                            <td width="2%">:</td>
                            <td>125</td>
                        </tr>
                        <tr>
                            <th width="30%">Academic Year </th>
                            <td width="2%">:</td>
                            <td>
                                <?php
                                    echo $year;
                                ?>
                            </td>
                        </tr>
                        <tr>
                            <th width="30%">Gender</th>
                            <td width="2%">:</td>
                            <td>
                                <?php
                                    echo $gender; 
                                ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
    </section>
<?php
    $connection->close();
?>
</body>

</html>