<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <title></title>
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="StyleSheet3.css" type="text/css" />
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'>

    <title>Attendance System</title>
</head>
<body>
    <section>
        <div class="icons">
            <div class="home">
                <img src="D:\nothing\home.JPG">
                <h2><a href=""><button class="button-base ripple">HOME</a></h2>
            </div>

            <div class="dashboard">
                <img src="D:\nothing\dashboard.JPG">
                <h2><a href="nothingstudent1.html"><button class="button-base ripple">DASHBOARD</a></h2>
            </div>
            <div class="ranking">
                <img src="D:\nothing\grade.jpg">
                <h2><a href="sample1.html"><button class="button-base ripple">RANKING</a></h2>
            </div>

            <div class="log out">
                <a href=""><button class="button-base ripple">LOG OUT</buttonclass=""></a>
            </div>
        </div>
    </section>
    <section class="a2d">
        <div class="student">
            <div class="box1">
                <div class="box-11">

                    <img src="D:\nothing\student.JPG" width="10%"height="25%" alt="student dp">
                </div>
                <div class="box-12">
                    <h3>Clatson J</h3>
                </div>
            </div>

            <div class="box2">
                <div class="box22">
                    <h3 class="mb-0"><i class="far fa-clone pr-1"></i>General Information</h3>
                </div>
                <div class="box2-body pt-0">
                    <table class="table-bordered">
                        <tr class="abc">
                            <th width="30%">Name</th>
                            <td width="2%">:</td>
                            <td>Clatson</td>
                        </tr>
                        <tr>
                            <th width="30%">Student ID </th>
                            <td width="2%">:</td>
                            <td>311121106027</td>
                        </tr>
                        <tr>
                            <th width="30%">Class</th>
                            <td width="2%">:</td>
                            <td>ECE</td>
                        </tr>
                        <tr>
                            <th width="30%">Roll</th>
                            <td width="2%">:</td>
                            <td>125</td>
                        </tr>
                        <tr>
                            <th width="30%">Academic Year </th>
                            <td width="2%">:</td>
                            <td>2020</td>
                        </tr>
                        <tr>
                            <th width="30%">Gender</th>
                            <td width="2%">:</td>
                            <td>Male</td>
                        </tr>
                    </table>
                </div>
            </div>
    </section>


</body>

</html>
