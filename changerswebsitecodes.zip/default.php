<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="homestyle.css" type="text/css" />
    <title></title>
</head>
<body>
    <header class="header">
        <a href="#" class="logo">GameChangers.School</a>
        <nav class="nav-items">
        </nav>
    </header>
    <main>
        <div class="intro">
            <br />
            <br />
            <br />
            <h1>Students Specialized Attendance Monitory</h1>
            <p>I am a student and I love to create future</p>
            <a href="https://login.changers.website/home.php"><button>login as a student</button></a>
            <br />
            <br />
            <a href="https://trial3.changers.website/facultylogin.php"><button>login as a teacher</button></a>
            <div>
                <div class="about-me">
                    <div class="about-me-text">
                        <br />
                        <br />
                        <br />
                        <h2>About GameChangers</h2>
                        <br />
                        <p><bold>GameChangers</bold> are the most wanted technological developers in a technical society.</p>
                    </div>
                </div>
</main>
    <footer class="footer">
        <div class="bottom-links">
            <div class="links">
                <span>Social Links</span>
                <a href="https://www.instagram.com/_.nayagan_.004/?hl=en"><img src="image\instagram.jpg"></a>
                <a href="https://www.facebook.com/profile.php?id=100083848835537"><img src="image\facebook.jpg"></a>  
                <a href="https://twitter.com/Antonayagam004"><img src="image\twitter.jpg"></a> 
                 </div>
        </div>
    </footer>
</body>
</html>
               