<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table>
        <tr>
            <th>Name</th>
            <th>ID</th>
            <th>Present</th>
            <th>No of working days</th>
            <th>Absent</th>
            <th>Percentage</th>
        </tr>
        y>
        <?php

            $servername = "localhost";
            $database = "u394450735_Student_data";
            $username = "u394450735_SIH";
            $password = "Game@123456789";
            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $database);
            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            
            $query = "SELECT * FROM leaderboard;";
            $result = $conn -> query($query);
            $resultcheck = mysqli_num_rows($result);
            if($resultcheck > 0){
                while ($row = mysqli_fetch_assoc($result)){
                   echo "<tr><td>".$row["name"] ."</td><td>".$row["id"] ."</td><td>".$row["present"] ."</td><td>".$row["absent"] ."</td><td>".$row["working"] ."</td><td>".$row["percentage"] ."</td><tr>";
                }
            }
                
            
        ?>
    </table>
</body>
</html>


